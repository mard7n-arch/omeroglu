# Zeynettin ÖMEROĞLU — Kişisel Portfolyo Sitesi

## Kurulum

```bash
npm install
npm run dev
```

## Üretim için Build

```bash
npm run build
```

Build çıktısı `dist/` klasöründe oluşur.

## Vercel ile Yayınlama

1. [vercel.com](https://vercel.com) adresinde ücretsiz hesap açın
2. GitHub'a bu projeyi yükleyin
3. Vercel'de "New Project" → GitHub repo seçin
4. Framework: **Vite** — Vercel otomatik algılar
5. Deploy edin → Siteniz yayında!

## İletişim Bilgilerini Güncelleme

`src/pages/Portfolio.tsx` dosyasındaki `settings` objesini düzenleyin.

## Fotoğraf Güncelleme

`public/profil.jpg` dosyasının üzerine yeni fotoğrafı aynı isimle kaydedin.

---
ORCID: https://orcid.org/0009-0003-8831-4919
