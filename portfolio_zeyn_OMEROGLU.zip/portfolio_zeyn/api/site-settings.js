import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('site_settings')
        .select('*')
        .order('key', { ascending: true });
      if (error) throw error;
      const settings = {};
      (data || []).forEach(row => { settings[row.key] = row.value; });
      return res.status(200).json(settings);
    }
    if (req.method === 'PUT') {
      const updates = req.body;
      const upserts = Object.entries(updates).map(([key, value]) => ({ key, value }));
      const { error } = await supabase.from('site_settings').upsert(upserts, { onConflict: 'key' });
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
