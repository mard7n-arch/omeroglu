import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Settings, LayoutDashboard, FolderKanban, BookOpen,
  MessageSquare, Image, LogOut, Plus, Trash2, Edit3, Eye,
  EyeOff, Star, StarOff, Save, X, ChevronDown, Upload, Zap,
  Users, FileText, BarChart3, RefreshCw, CheckCircle
} from 'lucide-react';

// ---- Types ----
interface Project {
  id?: number;
  title: string;
  description: string;
  category: string;
  tags: string[];
  image_url: string;
  demo_url: string;
  github_url: string;
  sort_order: number;
  published: boolean;
  featured: boolean;
}

interface BlogPost {
  id?: number;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  image_url: string;
  published: boolean;
  featured: boolean;
  created_at?: string;
}

interface Message {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  created_at: string;
}

interface Skill {
  id?: number;
  name: string;
  category: string;
  level: number;
  sort_order: number;
}

interface MediaItem {
  id: number;
  name: string;
  url: string;
  type: string;
  size: string;
  created_at: string;
}

interface Props {
  onLogout: () => void;
}

const navItems = [
  { id: 'dashboard', icon: <LayoutDashboard size={16} />, label: 'Gösterge Paneli' },
  { id: 'settings', icon: <Settings size={16} />, label: 'Site Ayarları' },
  { id: 'projects', icon: <FolderKanban size={16} />, label: 'Projeler' },
  { id: 'blog', icon: <BookOpen size={16} />, label: 'Blog' },
  { id: 'skills', icon: <Zap size={16} />, label: 'Yetenekler' },
  { id: 'messages', icon: <MessageSquare size={16} />, label: 'Mesajlar' },
  { id: 'media', icon: <Image size={16} />, label: 'Medya' },
];

export default function AdminPanel({ onLogout }: Props) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Data states
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [projects, setProjects] = useState<Project[]>([]);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [s, p, b, m, sk, med] = await Promise.all([
        fetch('/api/site-settings').then(r => r.json()),
        fetch('/api/projects').then(r => r.json()),
        fetch('/api/blog').then(r => r.json()),
        fetch('/api/contact').then(r => r.json()),
        fetch('/api/skills').then(r => r.json()),
        fetch('/api/media').then(r => r.json()),
      ]);
      setSettings(s || {});
      setProjects(Array.isArray(p) ? p : []);
      setPosts(Array.isArray(b) ? b : []);
      setMessages(Array.isArray(m) ? m : []);
      setSkills(Array.isArray(sk) ? sk : []);
      setMedia(Array.isArray(med) ? med : []);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const saveSettings = async () => {
    setLoading(true);
    await fetch('/api/site-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex" style={{ background: '#070a0f', fontFamily: 'DM Sans, sans-serif' }}>
      {/* Sidebar */}
      <aside
        className={`admin-sidebar flex-shrink-0 flex flex-col transition-all duration-300 ${sidebarOpen ? 'w-56' : 'w-16'}`}
        style={{ minHeight: '100vh', position: 'sticky', top: 0, height: '100vh', overflowY: 'auto' }}
      >
        <div className="p-4 border-b border-white/5">
          <div className={`flex items-center gap-3 ${!sidebarOpen && 'justify-center'}`}>
            <div className="w-8 h-8 rounded-lg bg-emerald-400/20 flex items-center justify-center flex-shrink-0">
              <span className="text-emerald-400 font-bold text-sm" style={{ fontFamily: 'Syne, sans-serif' }}>A</span>
            </div>
            {sidebarOpen && (
              <div>
                <div className="text-sm font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>Admin</div>
                <div className="text-xs text-slate-500">Yönetim Paneli</div>
              </div>
            )}
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`admin-nav-item w-full ${activeSection === item.id ? 'active' : ''} ${!sidebarOpen ? 'justify-center px-2' : ''}`}
              title={!sidebarOpen ? item.label : undefined}
            >
              {item.icon}
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-white/5">
          <button
            onClick={onLogout}
            className={`admin-nav-item w-full text-red-400 hover:bg-red-400/10 ${!sidebarOpen ? 'justify-center px-2' : ''}`}
          >
            <LogOut size={16} />
            {sidebarOpen && <span>Çıkış Yap</span>}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="sticky top-0 z-10 glass border-b border-white/5 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-500 hover:text-white transition-colors">
              <ChevronDown size={18} className={`transition-transform ${sidebarOpen ? 'rotate-90' : '-rotate-90'}`} />
            </button>
            <h1 className="text-base font-semibold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
              {navItems.find(n => n.id === activeSection)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={fetchAll} className="text-slate-500 hover:text-white transition-colors" title="Yenile">
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
            <a href="/" target="_blank" className="btn-outline text-xs py-1.5 px-4">
              Siteyi Gör
            </a>
          </div>
        </div>

        <div className="p-6">
          {activeSection === 'dashboard' && (
            <DashboardSection
              projects={projects}
              posts={posts}
              messages={messages}
              skills={skills}
            />
          )}
          {activeSection === 'settings' && (
            <SettingsSection
              settings={settings}
              setSettings={setSettings}
              onSave={saveSettings}
              loading={loading}
              saved={saved}
            />
          )}
          {activeSection === 'projects' && (
            <ProjectsAdmin
              projects={projects}
              onRefresh={fetchAll}
            />
          )}
          {activeSection === 'blog' && (
            <BlogAdmin posts={posts} onRefresh={fetchAll} />
          )}
          {activeSection === 'skills' && (
            <SkillsAdmin skills={skills} onRefresh={fetchAll} />
          )}
          {activeSection === 'messages' && (
            <MessagesAdmin messages={messages} onRefresh={fetchAll} />
          )}
          {activeSection === 'media' && (
            <MediaAdmin media={media} onRefresh={fetchAll} />
          )}
        </div>
      </main>
    </div>
  );
}

// ---- Dashboard ----
function DashboardSection({ projects, posts, messages, skills }: any) {
  const stats = [
    { label: 'Toplam Proje', value: projects.length, icon: <FolderKanban size={20} />, color: '#6ee7b7' },
    { label: 'Blog Yazısı', value: posts.length, icon: <BookOpen size={20} />, color: '#818cf8' },
    { label: 'Mesaj', value: messages.length, icon: <MessageSquare size={20} />, color: '#f472b6' },
    { label: 'Yetenek', value: skills.length, icon: <Zap size={20} />, color: '#fbbf24' },
  ];
  return (
    <div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s, i) => (
          <div key={i} className="admin-card">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs text-slate-500 uppercase tracking-wider">{s.label}</div>
              <div style={{ color: s.color }}>{s.icon}</div>
            </div>
            <div className="text-3xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>{s.value}</div>
          </div>
        ))}
      </div>
      <div className="admin-card">
        <h3 className="text-sm font-semibold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>Son Mesajlar</h3>
        {messages.slice(0, 5).map((m: any) => (
          <div key={m.id} className="flex items-start gap-3 py-3 border-b border-white/5 last:border-0">
            <div className="w-8 h-8 rounded-full bg-indigo-400/10 flex items-center justify-center text-indigo-400 text-xs font-bold flex-shrink-0">
              {m.name?.charAt(0)?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-white">{m.name}</span>
                <span className="text-xs text-slate-500">{m.email}</span>
              </div>
              <div className="text-xs text-slate-400 truncate mt-0.5">{m.message}</div>
            </div>
            <div className="text-xs text-slate-600 flex-shrink-0">
              {new Date(m.created_at).toLocaleDateString('tr-TR')}
            </div>
          </div>
        ))}
        {messages.length === 0 && <div className="text-sm text-slate-600 py-4 text-center">Henüz mesaj yok</div>}
      </div>
    </div>
  );
}

// ---- Settings ----
function SettingsSection({ settings, setSettings, onSave, loading, saved }: any) {
  const update = (key: string, value: string) => setSettings((prev: any) => ({ ...prev, [key]: value }));

  const sections = [
    {
      title: 'Site Genel',
      fields: [
        { key: 'site_name', label: 'Site Adı', placeholder: 'Portfolio' },
        { key: 'footer_tagline', label: 'Footer Slogan', placeholder: 'Dijital Deneyimler Tasarlıyorum' },
      ]
    },
    {
      title: 'Hero Bölümü',
      fields: [
        { key: 'hero_badge', label: 'Hero Rozet Metni', placeholder: 'Mevcut Projeler için Açık' },
        { key: 'hero_title_1', label: 'Başlık Satır 1', placeholder: 'Dijital' },
        { key: 'hero_title_2', label: 'Başlık Satır 2 (Renkli)', placeholder: 'Deneyimler' },
        { key: 'hero_title_3', label: 'Başlık Satır 3', placeholder: 'Tasarlıyorum' },
        { key: 'hero_subtitle', label: 'Alt Başlık', placeholder: 'Yaratıcı ve işlevsel dijital çözümler...', textarea: true },
      ]
    },
    {
      title: 'İstatistikler',
      fields: [
        { key: 'stat1_value', label: 'İstatistik 1 Değer', placeholder: '50+' },
        { key: 'stat1_label', label: 'İstatistik 1 Etiket', placeholder: 'Tamamlanan Proje' },
        { key: 'stat2_value', label: 'İstatistik 2 Değer', placeholder: '5+' },
        { key: 'stat2_label', label: 'İstatistik 2 Etiket', placeholder: 'Yıl Deneyim' },
        { key: 'stat3_value', label: 'İstatistik 3 Değer', placeholder: '30+' },
        { key: 'stat3_label', label: 'İstatistik 3 Etiket', placeholder: 'Mutlu Müşteri' },
      ]
    },
    {
      title: 'Hakkımda',
      fields: [
        { key: 'about_name', label: 'Ad Soyad', placeholder: 'Ad Soyad' },
        { key: 'about_role', label: 'Unvan', placeholder: 'Full Stack Developer' },
        { key: 'about_location', label: 'Konum', placeholder: 'İstanbul, Türkiye' },
        { key: 'about_experience', label: 'Deneyim', placeholder: '5+ Yıl Deneyim' },
        { key: 'about_status', label: 'Durum', placeholder: 'Müsait' },
        { key: 'about_bio', label: 'Biyografi', placeholder: 'Kendinizi tanıtın...', textarea: true },
        { key: 'profile_image', label: 'Profil Görseli URL', placeholder: 'https://...' },
        { key: 'cv_url', label: 'CV URL', placeholder: 'https://...' },
      ]
    },
    {
      title: 'İletişim & Sosyal',
      fields: [
        { key: 'contact_email', label: 'E-posta', placeholder: 'email@ornek.com' },
        { key: 'contact_phone', label: 'Telefon', placeholder: '+90 555 000 00 00' },
        { key: 'contact_subtitle', label: 'İletişim Alt Başlık', placeholder: 'Yeni bir proje için...' },
        { key: 'social_github', label: 'GitHub URL', placeholder: 'https://github.com/...' },
        { key: 'social_linkedin', label: 'LinkedIn URL', placeholder: 'https://linkedin.com/in/...' },
        { key: 'social_twitter', label: 'Twitter URL', placeholder: 'https://twitter.com/...' },
        { key: 'social_instagram', label: 'Instagram URL', placeholder: 'https://instagram.com/...' },
      ]
    },
    {
      title: 'SEO',
      fields: [
        { key: 'seo_title', label: 'SEO Başlık', placeholder: 'Ad Soyad | Portfolio' },
        { key: 'seo_description', label: 'SEO Açıklama', placeholder: 'Portfolio açıklaması...', textarea: true },
        { key: 'seo_keywords', label: 'Anahtar Kelimeler', placeholder: 'portfolio, geliştirici, tasarımcı' },
      ]
    },
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      {sections.map((sec, si) => (
        <div key={si} className="admin-card">
          <h3 className="text-sm font-bold text-white mb-5" style={{ fontFamily: 'Syne, sans-serif' }}>
            {sec.title}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {sec.fields.map((field: any) => (
              <div key={field.key} className={field.textarea ? 'sm:col-span-2' : ''}>
                <label className="admin-label">{field.label}</label>
                {field.textarea ? (
                  <textarea
                    value={settings[field.key] || ''}
                    onChange={e => update(field.key, e.target.value)}
                    className="admin-input resize-none"
                    rows={3}
                    placeholder={field.placeholder}
                  />
                ) : (
                  <input
                    type="text"
                    value={settings[field.key] || ''}
                    onChange={e => update(field.key, e.target.value)}
                    className="admin-input"
                    placeholder={field.placeholder}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="flex items-center gap-3">
        <button onClick={onSave} disabled={loading} className="btn-primary flex items-center gap-2">
          {loading ? (
            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : saved ? (
            <CheckCircle size={16} />
          ) : (
            <Save size={16} />
          )}
          {saved ? 'Kaydedildi!' : 'Değişiklikleri Kaydet'}
        </button>
      </div>
    </div>
  );
}

// ---- Projects Admin ----
function ProjectsAdmin({ projects, onRefresh }: any) {
  const [editing, setEditing] = useState<Project | null>(null);
  const [form, setForm] = useState<Project>({
    title: '', description: '', category: 'Web', tags: [],
    image_url: '', demo_url: '', github_url: '',
    sort_order: 0, published: true, featured: false,
  });
  const [tagInput, setTagInput] = useState('');
  const [loading, setLoading] = useState(false);

  const openNew = () => {
    setEditing(null);
    setForm({ title: '', description: '', category: 'Web', tags: [], image_url: '', demo_url: '', github_url: '', sort_order: projects.length, published: true, featured: false });
    setTagInput('');
  };

  const openEdit = (p: Project) => {
    setEditing(p);
    setForm({ ...p });
    setTagInput('');
  };

  const handleSave = async () => {
    setLoading(true);
    const method = editing ? 'PUT' : 'POST';
    const body = editing ? { ...form, id: (editing as any).id } : form;
    await fetch('/api/projects', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    setEditing(null);
    await onRefresh();
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Bu projeyi silmek istediğinizden emin misiniz?')) return;
    await fetch('/api/projects', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    onRefresh();
  };

  const togglePublish = async (p: any) => {
    await fetch('/api/projects', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: p.id, published: !p.published }),
    });
    onRefresh();
  };

  const addTag = () => {
    if (tagInput.trim() && !form.tags.includes(tagInput.trim())) {
      setForm({ ...form, tags: [...form.tags, tagInput.trim()] });
      setTagInput('');
    }
  };

  const removeTag = (tag: string) => setForm({ ...form, tags: form.tags.filter(t => t !== tag) });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="text-sm text-slate-400">{projects.length} proje</div>
        <button onClick={openNew} className="btn-primary text-sm py-2 px-5 flex items-center gap-2">
          <Plus size={14} /> Yeni Proje
        </button>
      </div>

      {/* Form modal */}
      <AnimatePresence>
        {(editing !== null || form.title !== undefined) && (
          <ProjectForm
            form={form}
            setForm={setForm}
            tagInput={tagInput}
            setTagInput={setTagInput}
            addTag={addTag}
            removeTag={removeTag}
            onSave={handleSave}
            onCancel={() => setEditing(undefined as any)}
            loading={loading}
            isNew={!editing}
          />
        )}
      </AnimatePresence>

      <div className="space-y-3">
        {projects.map((p: any) => (
          <div key={p.id} className="admin-card flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
              {p.image_url ? (
                <img src={p.image_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-emerald-400/10 flex items-center justify-center text-emerald-400 font-bold text-sm">
                  {p.title?.charAt(0)}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-sm font-semibold text-white truncate">{p.title}</span>
                {p.featured && <Star size={12} className="text-yellow-400 flex-shrink-0" />}
                <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${p.published ? 'bg-emerald-400/10 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                  {p.published ? 'Yayında' : 'Taslak'}
                </span>
              </div>
              <div className="text-xs text-slate-500 truncate">{p.category} · {p.description?.substring(0, 60)}...</div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button onClick={() => togglePublish(p)} className="text-slate-500 hover:text-white transition-colors" title={p.published ? 'Yayından Kaldır' : 'Yayınla'}>
                {p.published ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
              <button onClick={() => openEdit(p)} className="text-slate-500 hover:text-indigo-400 transition-colors">
                <Edit3 size={15} />
              </button>
              <button onClick={() => handleDelete(p.id)} className="text-slate-500 hover:text-red-400 transition-colors">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}
        {projects.length === 0 && (
          <div className="text-center py-12 text-slate-600">Henüz proje eklenmemiş</div>
        )}
      </div>
    </div>
  );
}

function ProjectForm({ form, setForm, tagInput, setTagInput, addTag, removeTag, onSave, onCancel, loading, isNew }: any) {
  return (
    <div className="admin-card mb-6 border-emerald-400/20">
      <div className="flex items-center justify-between mb-5">
        <h3 className="text-sm font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
          {isNew ? 'Yeni Proje Ekle' : 'Projeyi Düzenle'}
        </h3>
        <button onClick={onCancel} className="text-slate-500 hover:text-white"><X size={16} /></button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="admin-label">Proje Başlığı *</label>
          <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="admin-input" placeholder="Proje adı" />
        </div>
        <div className="sm:col-span-2">
          <label className="admin-label">Açıklama</label>
          <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="admin-input resize-none" rows={3} placeholder="Proje açıklaması..." />
        </div>
        <div>
          <label className="admin-label">Kategori</label>
          <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="admin-input">
            {['Web', 'Mobil', 'Tasarım', 'Backend'].map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="admin-label">Görsel URL</label>
          <input type="text" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} className="admin-input" placeholder="https://..." />
        </div>
        <div>
          <label className="admin-label">Demo URL</label>
          <input type="text" value={form.demo_url} onChange={e => setForm({ ...form, demo_url: e.target.value })} className="admin-input" placeholder="https://..." />
        </div>
        <div>
          <label className="admin-label">GitHub URL</label>
          <input type="text" value={form.github_url} onChange={e => setForm({ ...form, github_url: e.target.value })} className="admin-input" placeholder="https://github.com/..." />
        </div>
        <div className="sm:col-span-2">
          <label className="admin-label">Etiketler</label>
          <div className="flex gap-2 mb-2 flex-wrap">
            {form.tags.map((tag: string) => (
              <span key={tag} className="flex items-center gap-1 text-xs bg-emerald-400/10 text-emerald-400 px-2 py-1 rounded-full">
                {tag}
                <button onClick={() => removeTag(tag)}><X size={10} /></button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input type="text" value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addTag())} className="admin-input flex-1" placeholder="Etiket ekle ve Enter'a bas" />
            <button onClick={addTag} className="btn-outline text-sm px-4">Ekle</button>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.published} onChange={e => setForm({ ...form, published: e.target.checked })} className="accent-emerald-400" />
            <span className="text-sm text-slate-300">Yayınla</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.featured} onChange={e => setForm({ ...form, featured: e.target.checked })} className="accent-yellow-400" />
            <span className="text-sm text-slate-300">Öne Çıkar</span>
          </label>
        </div>
      </div>
      <div className="flex gap-3 mt-5">
        <button onClick={onSave} disabled={loading} className="btn-primary text-sm flex items-center gap-2">
          {loading ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> : <Save size={14} />}
          Kaydet
        </button>
        <button onClick={onCancel} className="btn-outline text-sm">İptal</button>
      </div>
    </div>
  );
}

// ---- Blog Admin ----
function BlogAdmin({ posts, onRefresh }: any) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ title: '', excerpt: '', content: '', category: 'Teknoloji', tags: [], image_url: '', published: false, featured: false });
  const [loading, setLoading] = useState(false);

  const openNew = () => {
    setEditing(null);
    setForm({ title: '', excerpt: '', content: '', category: 'Teknoloji', tags: [], image_url: '', published: false, featured: false });
    setShowForm(true);
  };

  const openEdit = (p: any) => {
    setEditing(p);
    setForm({ ...p });
    setShowForm(true);
  };

  const handleSave = async () => {
    setLoading(true);
    const method = editing ? 'PUT' : 'POST';
    const body = editing ? { ...form, id: editing.id } : form;
    await fetch('/api/blog', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    setShowForm(false);
    await onRefresh();
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Bu yazıyı silmek istediğinizden emin misiniz?')) return;
    await fetch('/api/blog', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    onRefresh();
  };

  const togglePublish = async (p: any) => {
    await fetch('/api/blog', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: p.id, published: !p.published }) });
    onRefresh();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="text-sm text-slate-400">{posts.length} yazı</div>
        <button onClick={openNew} className="btn-primary text-sm py-2 px-5 flex items-center gap-2">
          <Plus size={14} /> Yeni Yazı
        </button>
      </div>

      {showForm && (
        <div className="admin-card mb-6 border-indigo-400/20">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
              {editing ? 'Yazıyı Düzenle' : 'Yeni Blog Yazısı'}
            </h3>
            <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-white"><X size={16} /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="admin-label">Başlık *</label>
              <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="admin-input" placeholder="Yazı başlığı" />
            </div>
            <div className="sm:col-span-2">
              <label className="admin-label">Özet</label>
              <textarea value={form.excerpt} onChange={e => setForm({ ...form, excerpt: e.target.value })} className="admin-input resize-none" rows={2} placeholder="Kısa özet..." />
            </div>
            <div className="sm:col-span-2">
              <label className="admin-label">İçerik</label>
              <textarea value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} className="admin-input resize-none" rows={6} placeholder="Yazı içeriği..." />
            </div>
            <div>
              <label className="admin-label">Kategori</label>
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="admin-input">
                {['Teknoloji', 'Tasarım', 'Geliştirme', 'Duyuru', 'Kişisel'].map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="admin-label">Görsel URL</label>
              <input type="text" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} className="admin-input" placeholder="https://..." />
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.published} onChange={e => setForm({ ...form, published: e.target.checked })} className="accent-emerald-400" />
                <span className="text-sm text-slate-300">Yayınla</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.featured} onChange={e => setForm({ ...form, featured: e.target.checked })} className="accent-yellow-400" />
                <span className="text-sm text-slate-300">Öne Çıkar</span>
              </label>
            </div>
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={handleSave} disabled={loading} className="btn-primary text-sm flex items-center gap-2">
              {loading ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> : <Save size={14} />}
              Kaydet
            </button>
            <button onClick={() => setShowForm(false)} className="btn-outline text-sm">İptal</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {posts.map((p: any) => (
          <div key={p.id} className="admin-card flex items-center gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-sm font-semibold text-white truncate">{p.title}</span>
                {p.featured && <Star size={12} className="text-yellow-400 flex-shrink-0" />}
                <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${p.published ? 'bg-emerald-400/10 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                  {p.published ? 'Yayında' : 'Taslak'}
                </span>
              </div>
              <div className="text-xs text-slate-500 truncate">{p.category} · {new Date(p.created_at).toLocaleDateString('tr-TR')}</div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button onClick={() => togglePublish(p)} className="text-slate-500 hover:text-white transition-colors">
                {p.published ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
              <button onClick={() => openEdit(p)} className="text-slate-500 hover:text-indigo-400 transition-colors">
                <Edit3 size={15} />
              </button>
              <button onClick={() => handleDelete(p.id)} className="text-slate-500 hover:text-red-400 transition-colors">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}
        {posts.length === 0 && <div className="text-center py-12 text-slate-600">Henüz yazı eklenmemiş</div>}
      </div>
    </div>
  );
}

// ---- Skills Admin ----
function SkillsAdmin({ skills, onRefresh }: any) {
  const [form, setForm] = useState({ name: '', category: 'Frontend', level: 80, sort_order: 0 });
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (!form.name) return;
    setLoading(true);
    await fetch('/api/skills', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    setForm({ name: '', category: 'Frontend', level: 80, sort_order: skills.length });
    await onRefresh();
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    await fetch('/api/skills', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    onRefresh();
  };

  const updateLevel = async (id: number, level: number) => {
    await fetch('/api/skills', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, level }) });
    onRefresh();
  };

  const grouped = ['Frontend', 'Backend', 'Tasarım', 'Araçlar'].map(cat => ({
    name: cat,
    items: skills.filter((s: any) => s.category === cat),
  }));

  return (
    <div>
      <div className="admin-card mb-6">
        <h3 className="text-sm font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>Yeni Yetenek Ekle</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="admin-label">Ad</label>
            <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="admin-input" placeholder="React" />
          </div>
          <div>
            <label className="admin-label">Kategori</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="admin-input">
              {['Frontend', 'Backend', 'Tasarım', 'Araçlar'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="admin-label">Seviye (%)</label>
            <input type="number" min={0} max={100} value={form.level} onChange={e => setForm({ ...form, level: +e.target.value })} className="admin-input" />
          </div>
          <div className="flex items-end">
            <button onClick={handleAdd} disabled={loading} className="btn-primary w-full text-sm flex items-center justify-center gap-2">
              <Plus size={14} /> Ekle
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {grouped.map(group => (
          <div key={group.name} className="admin-card">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">{group.name}</h4>
            <div className="space-y-3">
              {group.items.map((skill: any) => (
                <div key={skill.id} className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-slate-300">{skill.name}</span>
                      <span className="text-xs text-emerald-400">{skill.level}%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${skill.level}%`, background: 'linear-gradient(90deg, #6ee7b7, #818cf8)' }} />
                    </div>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={skill.level}
                    onChange={e => updateLevel(skill.id, +e.target.value)}
                    className="w-20 accent-emerald-400"
                  />
                  <button onClick={() => handleDelete(skill.id)} className="text-slate-600 hover:text-red-400 transition-colors">
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
              {group.items.length === 0 && <div className="text-xs text-slate-600">Bu kategoride yetenek yok</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---- Messages Admin ----
function MessagesAdmin({ messages, onRefresh }: any) {
  const [selected, setSelected] = useState<any>(null);

  const handleDelete = async (id: number) => {
    if (!confirm('Bu mesajı silmek istediğinizden emin misiniz?')) return;
    await fetch('/api/contact', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    onRefresh();
    if (selected?.id === id) setSelected(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <div className="text-sm text-slate-400 mb-4">{messages.length} mesaj</div>
        <div className="space-y-2">
          {messages.map((m: any) => (
            <div
              key={m.id}
              onClick={() => setSelected(m)}
              className={`admin-card cursor-pointer transition-all hover:border-emerald-400/30 ${selected?.id === m.id ? 'border-emerald-400/30' : ''}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold text-white">{m.name}</span>
                    <span className="text-xs text-slate-500">{m.email}</span>
                  </div>
                  {m.subject && <div className="text-xs font-medium text-slate-400 mb-1">{m.subject}</div>}
                  <div className="text-xs text-slate-500 truncate">{m.message}</div>
                </div>
                <div className="flex flex-col items-end gap-2 flex-shrink-0">
                  <div className="text-xs text-slate-600">{new Date(m.created_at).toLocaleDateString('tr-TR')}</div>
                  <button onClick={e => { e.stopPropagation(); handleDelete(m.id); }} className="text-slate-600 hover:text-red-400 transition-colors">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
          {messages.length === 0 && <div className="text-center py-12 text-slate-600">Henüz mesaj yok</div>}
        </div>
      </div>

      {selected && (
        <div className="admin-card h-fit sticky top-20">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>Mesaj Detayı</h3>
            <button onClick={() => setSelected(null)} className="text-slate-500 hover:text-white"><X size={16} /></button>
          </div>
          <div className="space-y-3 mb-4">
            <div>
              <label className="admin-label">Gönderen</label>
              <div className="text-sm text-slate-200">{selected.name}</div>
            </div>
            <div>
              <label className="admin-label">E-posta</label>
              <div className="text-sm text-emerald-400">{selected.email}</div>
            </div>
            {selected.subject && (
              <div>
                <label className="admin-label">Konu</label>
                <div className="text-sm text-slate-200">{selected.subject}</div>
              </div>
            )}
            <div>
              <label className="admin-label">Mesaj</label>
              <div className="text-sm text-slate-300 leading-relaxed bg-white/5 rounded-lg p-3">{selected.message}</div>
            </div>
            <div>
              <label className="admin-label">Tarih</label>
              <div className="text-sm text-slate-400">{new Date(selected.created_at).toLocaleString('tr-TR')}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <a href={`mailto:${selected.email}`} className="btn-primary text-sm flex items-center gap-2 flex-1 justify-center">
              Yanıtla
            </a>
            <button onClick={() => handleDelete(selected.id)} className="btn-outline text-sm text-red-400 border-red-400/20 hover:bg-red-400/10">
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---- Media Admin ----
function MediaAdmin({ media, onRefresh }: any) {
  const [form, setForm] = useState({ name: '', url: '', type: 'image', size: '' });
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (!form.url) return;
    setLoading(true);
    await fetch('/api/media', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    setForm({ name: '', url: '', type: 'image', size: '' });
    await onRefresh();
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    await fetch('/api/media', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    onRefresh();
  };

  const images = media.filter((m: any) => m.type === 'image');
  const files = media.filter((m: any) => m.type !== 'image');

  return (
    <div>
      <div className="admin-card mb-6">
        <h3 className="text-sm font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>Medya Ekle</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="admin-label">Ad</label>
            <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="admin-input" placeholder="Dosya adı" />
          </div>
          <div>
            <label className="admin-label">URL</label>
            <input type="text" value={form.url} onChange={e => setForm({ ...form, url: e.target.value })} className="admin-input" placeholder="https://..." />
          </div>
          <div>
            <label className="admin-label">Tür</label>
            <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="admin-input">
              <option value="image">Görsel</option>
              <option value="video">Video</option>
              <option value="document">Döküman</option>
              <option value="other">Diğer</option>
            </select>
          </div>
        </div>
        <button onClick={handleAdd} disabled={loading} className="btn-primary text-sm mt-3 flex items-center gap-2">
          <Upload size={14} /> Ekle
        </button>
      </div>

      {images.length > 0 && (
        <div className="mb-6">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Görseller ({images.length})</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {images.map((m: any) => (
              <div key={m.id} className="relative group rounded-xl overflow-hidden aspect-square">
                <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => navigator.clipboard.writeText(m.url)}
                    className="text-xs text-white bg-white/20 px-2 py-1 rounded"
                  >
                    Kopyala
                  </button>
                  <button onClick={() => handleDelete(m.id)} className="text-red-400">
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 p-2">
                  <div className="text-xs text-white truncate">{m.name || 'Görsel'}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {files.length > 0 && (
        <div>
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Dosyalar ({files.length})</h4>
          <div className="space-y-2">
            {files.map((m: any) => (
              <div key={m.id} className="admin-card flex items-center gap-3">
                <FileText size={16} className="text-indigo-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-white truncate">{m.name}</div>
                  <div className="text-xs text-slate-500">{m.type} · {m.size}</div>
                </div>
                <a href={m.url} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-400 hover:underline">Aç</a>
                <button onClick={() => handleDelete(m.id)} className="text-slate-500 hover:text-red-400">
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {media.length === 0 && (
        <div className="text-center py-12 text-slate-600">Henüz medya eklenmemiş</div>
      )}
    </div>
  );
}
