import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import ProjectsSection from '../components/ProjectsSection';
import QualitySection from '../components/QualitySection';
import BlogSection from '../components/BlogSection';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

const settings: Record<string, string> = {
  site_name: 'Z.Ö.',
  hero_badge: 'Hemşire & Akademik Araştırmacı',
  hero_title_1: 'Sağlıkta',
  hero_title_2: 'Kaliteyi',
  hero_title_3: 'Yükseltiyorum.',
  hero_subtitle:
    'Hasta güvenliği, hastane akreditasyonu ve kanıta dayalı hemşirelik alanlarında çalışan hemşire, kalite uzmanı ve akademik araştırmacı.',
  stat1_value: '2+',
  stat1_label: 'Hakemli Makale',
  stat2_value: '6+',
  stat2_label: 'Yıl Deneyim',
  stat3_value: '3+',
  stat3_label: 'Kongre',
  about_name: 'Zeynettin ÖMEROĞLU',
  about_role: 'Hemşire | Kalite Birimi | Araştırmacı',
  about_location: 'Aydın, Türkiye',
  about_experience: '6+ Yıl Deneyim',
  about_bio:
    "Aydın Devlet Hastanesi Kalite Birimi'nde görev yapan hemşire ve akademisyen. İzmir Tınaztepe Üniversitesi'nde Cerrahi Hastalıkları Hemşireliği alanında tezsis yüksek lisans derecesine sahibim. SKS, JCI ve SAS akreditasyon standartları, hasta güvenliği kültürü, sistematik derleme ve meta-analiz yöntemleri konularında çalışmalar yürütmekteyim.",
  about_status: 'Aktif',
  profile_image: '/profil.jpg',
  contact_email: 'omerogluzeynettin@gmail.com',
  contact_phone: '+90 542 468 3914',
  social_instagram: 'https://www.instagram.com/by.omeroglu',
  social_orcid: 'https://orcid.org/0009-0003-8831-4919',
  quality_subtitle:
    'Hasta güvenliğini ve kanıta dayalı uygulamaları temel alarak, sağlık hizmetlerinin kalitesini sürekli iyileştirmeyi hedefliyorum.',
  quality_quote:
    'Kaliteli sağlık hizmeti bir tercih değil, her hastanın hakkıdır. Her akreditasyon standartının arkında bir insan hayatı vardır.',
  footer_tagline: 'Sağlıkta Kalite & Kanıta Dayalı Hemşirelik',
};

const skills = [
  { id: 1, name: 'SKS (Sağlıkta Kalite Standartları)', category: 'Kalite Yönetimi', level: 92 },
  { id: 2, name: 'JCI Akreditasyonu', category: 'Kalite Yönetimi', level: 85 },
  { id: 3, name: 'SAS / TÜSKA', category: 'Kalite Yönetimi', level: 83 },
  { id: 4, name: 'Hasta Güvenliği Kültürü', category: 'Kalite Yönetimi', level: 90 },
  { id: 5, name: 'Sistematik Derleme & Meta-Analiz', category: 'Araştırma', level: 88 },
  { id: 6, name: 'PRISMA-2020 Metodolojisi', category: 'Araştırma', level: 90 },
  { id: 7, name: 'İstatistiksel Analiz (SPSS)', category: 'Araştırma', level: 75 },
  { id: 8, name: 'Akademik Yayın Yönetimi', category: 'Araştırma', level: 82 },
  { id: 9, name: 'Cerrahi Hastalıkları Hemşireliği', category: 'Klinik', level: 95 },
  { id: 10, name: 'Perioperatif Hemşirelik', category: 'Klinik', level: 90 },
  { id: 11, name: 'Kan Transfüzyonu Güvenliği', category: 'Klinik', level: 88 },
  { id: 12, name: 'Sağlık Yönetimi & Raporlama', category: 'Yönetim', level: 85 },
  { id: 13, name: 'Kongre & Sunum Hazırlama', category: 'Yönetim', level: 80 },
  { id: 14, name: 'Eğitim & Mentorluk', category: 'Yönetim', level: 82 },
];

const projects = [
  {
    id: 1,
    title: "Türkiye'de Hastane Akreditasyonunun Hasta Güvenliği ve Verimliliğe Etkisi",
    description:
      "Türkiye'deki hastane akreditasyonu uygulamalarının hasta güvenliği ve sağlık hizmeti verimliliği üzerindeki etkisini inceleyen kapsamlı meta-analiz çalışması. PRISMA-2020 metodolojisi ile yürütüldü.",
    category: 'Meta-Analiz',
    tags: ['Akreditasyon', 'Meta-Analiz', 'PRISMA', 'Hasta Güvenliği'],
    image_url: '',
    demo_url: 'https://orcid.org/0009-0003-8831-4919',
    github_url: '',
    featured: true,
    published: true,
  },
  {
    id: 2,
    title: 'Cerrahi Hastalarda Kan Transfüzyon Reaksiyonları',
    description:
      'Cerrahi hastalarda (n=6.352) kan transfüzyon reaksiyonlarını inceleyen retrospektif kohort çalışması. Reaksiyon sıklığı, türleri ve risk faktörleri analiz edildi.',
    category: 'Araştırma',
    tags: ['Kan Transfüzyonu', 'Cerrahi Hemşireliği', 'Kohort', 'Hasta Güvenliği'],
    image_url: '',
    demo_url: '',
    github_url: '',
    featured: false,
    published: true,
  },
  {
    id: 3,
    title: 'Preoperatif Anksiyete, Depresyon ve Postoperatif Deliryum',
    description:
      'Kalça kırığı cerrahisi geçiren hastalarda preoperatif anksiyete/depresyon ile postoperatif deliryum arasındaki ilişkiyi araştıran çalışma. HAD ve Nu-DESC ölçekleri kullanıldı.',
    category: 'Araştırma',
    tags: ['Anksiyete', 'Deliryum', 'HAD', 'Nu-DESC', 'Kalça Kırığı'],
    image_url: '',
    demo_url: '',
    github_url: '',
    featured: false,
    published: true,
  },
];

const posts: any[] = [];

export default function Portfolio() {
  return (
    <div className="noise-bg" style={{ background: '#070a0f' }}>
      <Navbar settings={settings} />
      <HeroSection settings={settings} />
      <div className="section-divider" />
      <AboutSection settings={settings} skills={skills} />
      <div className="section-divider" />
      <ProjectsSection projects={projects} />
      <div className="section-divider" />
      <QualitySection settings={settings} />
      <div className="section-divider" />
      <BlogSection posts={posts} />
      <div className="section-divider" />
      <ContactSection settings={settings} />
      <Footer settings={settings} />
    </div>
  );
}
