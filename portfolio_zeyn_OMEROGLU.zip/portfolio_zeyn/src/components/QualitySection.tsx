import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Shield, BookOpen, Award, HeartPulse, Microscope, Users } from 'lucide-react';

interface Props {
  settings: Record<string, string>;
}

const qualities = [
  {
    icon: <Shield size={24} />,
    title: 'Hasta Güvenliği',
    desc: 'SKS ve JCI standartları çerçevesinde hasta güvenliği kültürünü kurumsal düzeyde geliştiriyorum.',
    color: '#6ee7b7',
  },
  {
    icon: <BookOpen size={24} />,
    title: 'Kanıta Dayalı Hemşirelik',
    desc: 'PRISMA-2020 metodolojisiyle sistematik derleme ve meta-analiz çalışmaları yürütüyorum.',
    color: '#818cf8',
  },
  {
    icon: <Award size={24} />,
    title: 'Akreditasyon Uzmanlığı',
    desc: 'Hastane akreditasyon süreçlerini ve kalite standartlarını derinlemesine biliyor, sahada uyguluyorum.',
    color: '#f472b6',
  },
  {
    icon: <HeartPulse size={24} />,
    title: 'Klinik Yetkinlik',
    desc: 'Cerrahi ve perioperatif hemşirelik alanında kapsamlı klinik deneyim ve uzmanlık.',
    color: '#fbbf24',
  },
  {
    icon: <Microscope size={24} />,
    title: 'Akademik Katkı',
    desc: 'Hakemli dergilerde yayınlar ve ulusal kongrelerde sunumlarla bilime katkı sağlıyorum.',
    color: '#34d399',
  },
  {
    icon: <Users size={24} />,
    title: 'Eğitim & Mentorluk',
    desc: 'Meslektaşlara kongre, yayın hazırlığı ve kalite yönetimi konularında rehberlik ediyorum.',
    color: '#a78bfa',
  },
];

export default function QualitySection({ settings }: Props) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="quality" className="relative py-32 overflow-hidden" ref={ref}>
      <div className="absolute top-0 left-0 right-0 overflow-hidden py-4 border-y border-white/5">
        <div className="animate-marquee whitespace-nowrap flex gap-12 text-xs font-semibold uppercase tracking-widest text-white/10">
          {Array.from({ length: 10 }).map((_, i) => (
            <span key={i} className="flex items-center gap-12">
              <span>Hasta Güvenliği</span>
              <span className="text-emerald-400/30">✦</span>
              <span>Akreditasyon</span>
              <span className="text-indigo-400/30">✦</span>
              <span>Kanıta Dayalı Hemşirelik</span>
              <span className="text-pink-400/30">✦</span>
              <span>Kalite Yönetimi</span>
              <span className="text-emerald-400/30">✦</span>
            </span>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 pt-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="tag mb-4 inline-block">Uzmanlık Alanları</span>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
            Neden <span className="gradient-text">Bu Alandayım?</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            {settings.quality_subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {qualities.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="glass gradient-border rounded-2xl p-8 card-hover group"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110"
                style={{ background: `${item.color}15`, color: item.color }}
              >
                {item.icon}
              </div>
              <h3 className="text-lg font-bold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
                {item.title}
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
              <div
                className="mt-6 h-0.5 w-0 group-hover:w-full transition-all duration-500 rounded-full"
                style={{ background: `linear-gradient(90deg, ${item.color}, transparent)` }}
              />
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-20 glass gradient-border rounded-3xl p-12 text-center"
        >
          <div className="text-6xl text-emerald-400/30 font-serif mb-4">"</div>
          <p className="text-xl md:text-2xl text-slate-300 leading-relaxed max-w-3xl mx-auto" style={{ fontFamily: 'Syne, sans-serif' }}>
            {settings.quality_quote}
          </p>
          <div className="mt-6 text-sm text-slate-500">— {settings.about_name}</div>
        </motion.div>
      </div>
    </section>
  );
}
