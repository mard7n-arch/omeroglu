import { motion } from 'framer-motion';
import { ArrowDown, Sparkles } from 'lucide-react';
import { lazy, Suspense } from 'react';

const ThreeScene = lazy(() => import('./ThreeScene'));

interface Props {
  settings: Record<string, string>;
}

export default function HeroSection({ settings }: Props) {
  const scrollToNext = () => {
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background glows */}
      <div className="hero-glow w-[600px] h-[600px] bg-emerald-500/10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-glow-pulse" />
      <div className="hero-glow w-[400px] h-[400px] bg-indigo-500/10 top-1/4 right-1/4 animate-glow-pulse" style={{ animationDelay: '1.5s' }} />
      <div className="hero-glow w-[300px] h-[300px] bg-pink-500/8 bottom-1/4 left-1/4 animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* 3D Scene */}
      <div className="absolute right-0 top-0 w-full md:w-1/2 h-full opacity-80">
        <Suspense fallback={null}>
          <ThreeScene />
        </Suspense>
      </div>

      {/* Grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(110,231,183,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(110,231,183,0.5) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      {/* Content */}
      <div className="content-layer max-w-7xl mx-auto px-6 pt-28 pb-20 w-full">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex items-center gap-2 mb-6"
          >
            <span className="tag flex items-center gap-1.5">
              <Sparkles size={10} />
              {settings.hero_badge || 'Mevcut Projeler için Açık'}
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tight mb-6"
            style={{ fontFamily: 'Syne, sans-serif' }}
          >
            <span className="text-white block">{settings.hero_title_1 || 'Dijital'}</span>
            <span className="gradient-text block">{settings.hero_title_2 || 'Deneyimler'}</span>
            <span className="text-slate-400 block">{settings.hero_title_3 || 'Tasarlıyorum'}</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-slate-400 text-lg md:text-xl leading-relaxed mb-10 max-w-xl"
          >
            {settings.hero_subtitle || 'Yaratıcı ve işlevsel dijital çözümler üretiyorum. Modern teknolojiler ile etkileyici kullanıcı deneyimleri tasarlıyorum.'}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="flex flex-wrap gap-4"
          >
            <button
              onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="btn-primary"
            >
              Projeleri Gör
            </button>
            <button
              onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="btn-outline"
            >
              İletişime Geç
            </button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="flex flex-wrap gap-8 mt-16"
          >
            {[
              { value: settings.stat1_value || '50+', label: settings.stat1_label || 'Tamamlanan Proje' },
              { value: settings.stat2_value || '5+', label: settings.stat2_label || 'Yıl Deneyim' },
              { value: settings.stat3_value || '30+', label: settings.stat3_label || 'Mutlu Müşteri' },
            ].map((stat, i) => (
              <div key={i} className="text-center md:text-left">
                <div className="text-3xl font-bold gradient-text" style={{ fontFamily: 'Syne, sans-serif' }}>{stat.value}</div>
                <div className="text-xs text-slate-500 mt-1 uppercase tracking-widest">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.button
        onClick={scrollToNext}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-500 hover:text-emerald-400 transition-colors"
      >
        <span className="text-xs tracking-widest uppercase">Keşfet</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ArrowDown size={16} />
        </motion.div>
      </motion.button>
    </section>
  );
}
