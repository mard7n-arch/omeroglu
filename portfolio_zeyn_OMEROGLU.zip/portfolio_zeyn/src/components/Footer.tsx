import { motion } from 'framer-motion';

interface Props {
  settings: Record<string, string>;
}

export default function Footer({ settings }: Props) {
  return (
    <footer className="relative border-t border-white/5 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="section-divider mb-12" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="text-xl font-bold gradient-text mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>
              {settings.site_name || 'Portfolio'}
            </div>
            <div className="text-xs text-slate-600">
              {settings.footer_tagline || 'Dijital Deneyimler Tasarlıyorum'}
            </div>
          </div>
          <div className="text-xs text-slate-600 text-center md:text-right">
            <div>© {new Date().getFullYear()} {settings.about_name || 'Portfolio'}. Tüm hakları saklıdır.</div>
            <div className="mt-1 text-slate-700">
              Sevgiyle tasarlandı ve geliştirildi ✦
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
