import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { User, MapPin, Calendar } from 'lucide-react';

interface Props {
  settings: Record<string, string>;
  skills: any[];
}

const skillCategories = ['Kalite Yönetimi', 'Araştırma', 'Klinik', 'Yönetim'];

export default function AboutSection({ settings, skills }: Props) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  const grouped = skillCategories.map(cat => ({
    name: cat,
    items: skills.filter(s => s.category === cat),
  })).filter(g => g.items.length > 0);

  return (
    <section id="about" className="relative py-32 overflow-hidden" ref={ref}>
      <div className="hero-glow w-[400px] h-[400px] bg-indigo-500/8 top-1/2 left-0 -translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <span className="tag mb-4 inline-block">Hakkımda</span>
          <h2 className="text-4xl md:text-6xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
            Beni <span className="gradient-text">Tanıyın</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: About content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="glass gradient-border rounded-2xl p-8 mb-8">
              <div className="flex items-start gap-6 mb-6">
                <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 gradient-border">
                  {settings.profile_image ? (
                    <img src={settings.profile_image} alt="Profil" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-emerald-500/20 to-indigo-500/20 flex items-center justify-center">
                      <User size={32} className="text-emerald-400" />
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>
                    {settings.about_name}
                  </h3>
                  <p className="text-emerald-400 text-sm font-medium">{settings.about_role}</p>
                  <div className="flex flex-wrap gap-4 mt-3">
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <MapPin size={12} className="text-emerald-400" />
                      {settings.about_location}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Calendar size={12} className="text-indigo-400" />
                      {settings.about_experience}
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-slate-400 leading-relaxed text-sm mb-6">
                {settings.about_bio}
              </p>
            </div>

            {/* Info grid */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: 'Kurum', value: 'Aydın Devlet Hastanesi' },
                { label: 'Birim', value: 'Kalite Birimi' },
                { label: 'Eğitim', value: 'Cerrahi Hemşireliği YL' },
                { label: 'Durum', value: settings.about_status, highlight: true },
              ].map((info, i) => (
                <div key={i} className="glass rounded-xl p-4">
                  <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">{info.label}</div>
                  <div className={`text-sm font-medium ${info.highlight ? 'text-emerald-400' : 'text-slate-200'}`}>
                    {info.value}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Skills */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <h3 className="text-2xl font-bold text-white mb-8" style={{ fontFamily: 'Syne, sans-serif' }}>
              Yetkinlikler & <span className="gradient-text">Uzmanlıklar</span>
            </h3>

            <div className="space-y-8">
              {grouped.map((group, gi) => (
                <div key={gi}>
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-4">{group.name}</div>
                  <div className="space-y-3">
                    {group.items.map((skill, si) => (
                      <motion.div
                        key={skill.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={inView ? { opacity: 1, x: 0 } : {}}
                        transition={{ delay: 0.5 + si * 0.1 }}
                      >
                        <div className="flex justify-between mb-1.5">
                          <span className="text-sm text-slate-300">{skill.name}</span>
                          <span className="text-xs text-emerald-400 font-medium">{skill.level}%</span>
                        </div>
                        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={inView ? { width: `${skill.level}%` } : {}}
                            transition={{ duration: 1, delay: 0.6 + si * 0.1, ease: 'easeOut' }}
                            className="h-full rounded-full"
                            style={{ background: 'linear-gradient(90deg, #6ee7b7, #818cf8)' }}
                          />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
