import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Send, Mail, Phone, MapPin, Instagram, ExternalLink } from 'lucide-react';

interface Props {
  settings: Record<string, string>;
}

export default function ContactSection({ settings }: Props) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const mailtoLink = `mailto:${settings.contact_email}?subject=${encodeURIComponent(form.subject)}&body=${encodeURIComponent(
      `Ad Soyad: ${form.name}\nE-posta: ${form.email}\n\n${form.message}`
    )}`;
    window.open(mailtoLink);
    setTimeout(() => {
      setSuccess(true);
      setForm({ name: '', email: '', subject: '', message: '' });
      setLoading(false);
    }, 600);
  };

  const socials = [
    {
      icon: <Instagram size={18} />,
      href: settings.social_instagram,
      label: 'Instagram',
      handle: '@by.omeroglu',
      color: '#f472b6',
    },
    {
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm.14 4.37c.54 0 .976.436.976.976s-.436.976-.976.976a.977.977 0 0 1-.976-.976c0-.54.437-.976.976-.976zM9.5 8.5h5v1.5h-1.5V18H11.5v-8H9.5V8.5z" />
        </svg>
      ),
      href: settings.social_orcid,
      label: 'ORCID',
      handle: '0009-0003-8831-4919',
      color: '#a6ce39',
    },
  ].filter(s => s.href);

  const contactInfo = [
    { icon: <Mail size={20} />, label: 'E-posta', value: settings.contact_email, color: '#6ee7b7', href: `mailto:${settings.contact_email}` },
    { icon: <Phone size={20} />, label: 'Telefon', value: settings.contact_phone, color: '#818cf8', href: `tel:${settings.contact_phone}` },
    { icon: <MapPin size={20} />, label: 'Konum', value: 'Aydın Devlet Hastanesi, Aydın', color: '#f472b6', href: null },
  ];

  return (
    <section id="contact" className="relative py-32 overflow-hidden" ref={ref}>
      <div className="hero-glow w-[500px] h-[500px] bg-indigo-500/8 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="tag mb-4 inline-block">İletişim</span>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            Benimle <span className="gradient-text">İletişime Geç</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Araştırma işbirlikleri, kongre davetleri veya kalite yönetimi konularında görüşmek ister misiniz?
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left info */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-2 space-y-4"
          >
            {contactInfo.map((item, i) => (
              <div key={i} className="glass gradient-border rounded-2xl p-5 flex items-start gap-4">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: `${item.color}15`, color: item.color }}
                >
                  {item.icon}
                </div>
                <div>
                  <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">{item.label}</div>
                  {item.href ? (
                    <a href={item.href} className="text-sm font-medium text-slate-200 hover:text-emerald-400 transition-colors">
                      {item.value}
                    </a>
                  ) : (
                    <div className="text-sm font-medium text-slate-200">{item.value}</div>
                  )}
                </div>
              </div>
            ))}

            {/* Socials */}
            {socials.length > 0 && (
              <div className="glass gradient-border rounded-2xl p-6">
                <div className="text-xs text-slate-500 uppercase tracking-widest mb-4">Platformlar</div>
                <div className="space-y-4">
                  {socials.map((s, i) => (
                    <a
                      key={i}
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 text-sm text-slate-300 hover:text-white transition-colors group"
                    >
                      <span style={{ color: s.color }}>{s.icon}</span>
                      <div>
                        <div className="font-medium text-xs">{s.label}</div>
                        <div className="text-slate-500 text-xs">{s.handle}</div>
                      </div>
                      <ExternalLink size={12} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: s.color }} />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </motion.div>

          {/* Right: form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-3"
          >
            <div className="glass gradient-border rounded-2xl p-8">
              {success ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
                    <Send size={28} className="text-emerald-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
                    Mesajınız İletildi!
                  </h3>
                  <p className="text-slate-400 text-sm">E-posta uygulamanız açıldı. En kısa sürede geri dönüş yapacağım.</p>
                  <button
                    onClick={() => setSuccess(false)}
                    className="mt-6 text-xs text-slate-500 hover:text-emerald-400 transition-colors"
                  >
                    Yeni mesaj gönder
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {[
                      { label: 'Adınız', key: 'name', type: 'text', placeholder: 'Ad Soyad' },
                      { label: 'E-posta', key: 'email', type: 'email', placeholder: 'ornek@mail.com' },
                    ].map(f => (
                      <div key={f.key}>
                        <label className="block text-xs text-slate-500 uppercase tracking-widest mb-2">{f.label}</label>
                        <input
                          type={f.type}
                          required
                          placeholder={f.placeholder}
                          value={(form as any)[f.key]}
                          onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
                        />
                      </div>
                    ))}
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 uppercase tracking-widest mb-2">Konu</label>
                    <input
                      type="text"
                      required
                      placeholder="Araştırma işbirliği, kongre daveti..."
                      value={form.subject}
                      onChange={e => setForm(prev => ({ ...prev, subject: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 uppercase tracking-widest mb-2">Mesajınız</label>
                    <textarea
                      required
                      rows={5}
                      placeholder="Mesajınızı buraya yazınız..."
                      value={form.message}
                      onChange={e => setForm(prev => ({ ...prev, message: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500/50 transition-colors resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {loading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send size={16} />
                        Gönder
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
