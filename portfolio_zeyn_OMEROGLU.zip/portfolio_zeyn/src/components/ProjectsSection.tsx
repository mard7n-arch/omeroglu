import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { ExternalLink, ArrowRight, BookOpen } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  category: string;
  tags: string[];
  image_url: string;
  demo_url: string;
  github_url: string;
  featured: boolean;
  published: boolean;
}

interface Props {
  projects: Project[];
}

const categories = ['Tümü', 'Meta-Analiz', 'Araştırma'];

const categoryColors: Record<string, string> = {
  'Meta-Analiz': '#6ee7b7',
  'Araştırma': '#818cf8',
};

export default function ProjectsSection({ projects }: Props) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const [activeCategory, setActiveCategory] = useState('Tümü');

  const filtered =
    activeCategory === 'Tümü'
      ? projects
      : projects.filter(p => p.category === activeCategory);

  const featured = projects.find(p => p.featured);
  const rest = filtered.filter(p => !p.featured || activeCategory !== 'Tümü');

  return (
    <section id="projects" className="relative py-32 overflow-hidden" ref={ref}>
      <div className="hero-glow w-[500px] h-[500px] bg-pink-500/6 top-1/2 right-0 -translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <span className="tag mb-4 inline-block">Araştırmalar</span>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <h2 className="text-4xl md:text-6xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
              Seçili <span className="gradient-text">Çalışmalar</span>
            </h2>
            <div className="flex gap-2 flex-wrap">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-widest transition-all duration-300 ${
                    activeCategory === cat
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'text-slate-500 border border-white/10 hover:text-slate-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Featured project */}
        {activeCategory === 'Tümü' && featured && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="glass gradient-border rounded-3xl p-8 md:p-10 mb-8 card-hover group"
          >
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: '#6ee7b715', color: '#6ee7b7' }}>
                <BookOpen size={28} />
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-3 mb-4">
                  <span className="tag text-xs" style={{ color: categoryColors[featured.category] || '#6ee7b7' }}>
                    ★ Öne Çıkan · {featured.category}
                  </span>
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
                  {featured.title}
                </h3>
                <p className="text-slate-400 leading-relaxed mb-6">{featured.description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {featured.tags.map(tag => (
                    <span key={tag} className="px-3 py-1 rounded-full text-xs bg-white/5 text-slate-400 border border-white/10">
                      {tag}
                    </span>
                  ))}
                </div>
                {featured.demo_url && (
                  <a
                    href={featured.demo_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-emerald-400 text-sm font-medium hover:text-emerald-300 transition-colors"
                  >
                    <ExternalLink size={14} />
                    ORCID'de Görüntüle
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {/* Other projects */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(activeCategory === 'Tümü' ? projects.filter(p => !p.featured) : filtered).map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
              className="glass gradient-border rounded-2xl p-7 card-hover group"
            >
              <div className="flex items-start gap-4 mb-4">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: `${categoryColors[project.category] || '#6ee7b7'}15`,
                    color: categoryColors[project.category] || '#6ee7b7',
                  }}
                >
                  <BookOpen size={18} />
                </div>
                <span
                  className="text-xs font-semibold uppercase tracking-widest mt-2.5"
                  style={{ color: categoryColors[project.category] || '#6ee7b7' }}
                >
                  {project.category}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mb-3 leading-snug" style={{ fontFamily: 'Syne, sans-serif' }}>
                {project.title}
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-5">{project.description}</p>
              <div className="flex flex-wrap gap-2 mb-5">
                {project.tags.map(tag => (
                  <span key={tag} className="px-2.5 py-1 rounded-full text-xs bg-white/5 text-slate-500 border border-white/8">
                    {tag}
                  </span>
                ))}
              </div>
              {project.demo_url && (
                <a
                  href={project.demo_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
                >
                  <ArrowRight size={12} />
                  İncele
                </a>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
