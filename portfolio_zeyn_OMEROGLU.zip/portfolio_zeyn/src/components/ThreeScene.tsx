import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial, Float, Stars } from '@react-three/drei';
import * as THREE from 'three';

function AnimatedSphere() {
  const meshRef = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 0.15;
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
  });
  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <Sphere ref={meshRef} args={[1.8, 100, 200]} scale={1}>
        <MeshDistortMaterial
          color="#0d1117"
          attach="material"
          distort={0.4}
          speed={2}
          roughness={0.1}
          metalness={0.8}
          wireframe={false}
        >
          <primitive attach="emissiveMap" object={new THREE.Texture()} />
        </MeshDistortMaterial>
      </Sphere>
    </Float>
  );
}

function GlowRing({ radius, color, speed }: { radius: number; color: string; speed: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.x = Math.sin(state.clock.elapsedTime * speed) * 0.3;
      ref.current.rotation.y = state.clock.elapsedTime * speed * 0.5;
      ref.current.rotation.z = Math.cos(state.clock.elapsedTime * speed * 0.7) * 0.2;
    }
  });
  const geometry = useMemo(() => new THREE.TorusGeometry(radius, 0.015, 16, 100), [radius]);
  return (
    <mesh ref={ref} geometry={geometry}>
      <meshBasicMaterial color={color} transparent opacity={0.6} />
    </mesh>
  );
}

function ParticleField() {
  const count = 200;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return pos;
  }, []);

  const ref = useRef<THREE.Points>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.03} color="#6ee7b7" transparent opacity={0.6} sizeAttenuation />
    </points>
  );
}

export default function ThreeScene() {
  return (
    <Canvas
      className="three-canvas"
      camera={{ position: [0, 0, 6], fov: 50 }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.2} />
      <pointLight position={[5, 5, 5]} intensity={1} color="#6ee7b7" />
      <pointLight position={[-5, -5, -5]} intensity={0.5} color="#818cf8" />
      <pointLight position={[0, 5, -5]} intensity={0.3} color="#f472b6" />
      <Stars radius={100} depth={50} count={3000} factor={3} saturation={0} fade speed={0.5} />
      <AnimatedSphere />
      <GlowRing radius={2.8} color="#6ee7b7" speed={0.3} />
      <GlowRing radius={3.4} color="#818cf8" speed={0.2} />
      <GlowRing radius={4.0} color="#f472b6" speed={0.15} />
      <ParticleField />
    </Canvas>
  );
}
