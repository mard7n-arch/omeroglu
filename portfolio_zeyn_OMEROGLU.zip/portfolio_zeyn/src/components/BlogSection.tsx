import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Calendar, Clock, ArrowRight, Tag } from 'lucide-react';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  tags: string[];
  image_url: string;
  created_at: string;
  featured: boolean;
  published: boolean;
}

interface Props {
  posts: BlogPost[];
}

function formatDate(dateStr: string) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
}

export default function BlogSection({ posts }: Props) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  const featured = posts.find(p => p.featured) || posts[0];
  const rest = posts.filter(p => p.id !== featured?.id).slice(0, 4);

  return (
    <section id="blog" className="relative py-32 overflow-hidden" ref={ref}>
      <div className="hero-glow w-[400px] h-[400px] bg-emerald-500/6 bottom-0 left-1/2 -translate-x-1/2" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16"
        >
          <div>
            <span className="tag mb-4 inline-block">Blog & Duyurular</span>
            <h2 className="text-4xl md:text-6xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
              Son <span className="gradient-text">Yazılar</span>
            </h2>
          </div>
          <button className="btn-outline inline-flex items-center gap-2 self-start md:self-auto">
            Tümünü Gör <ArrowRight size={14} />
          </button>
        </motion.div>

        {posts.length === 0 ? (
          <div className="text-center py-20 text-slate-500">Henüz blog yazısı bulunmuyor.</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Featured post */}
            {featured && (
              <motion.article
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="lg:col-span-2 glass gradient-border rounded-2xl overflow-hidden card-hover group cursor-pointer"
              >
                <div className="relative overflow-hidden h-64">
                  {featured.image_url ? (
                    <img
                      src={featured.image_url}
                      alt={featured.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-emerald-500/20 to-indigo-500/20 flex items-center justify-center">
                      <span className="text-5xl font-bold gradient-text" style={{ fontFamily: 'Syne, sans-serif' }}>
                        {featured.title?.charAt(0)}
                      </span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="tag">Öne Çıkan</span>
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center gap-4 text-xs text-slate-500 mb-4">
                    <span className="flex items-center gap-1.5">
                      <Calendar size={11} />
                      {formatDate(featured.created_at)}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Tag size={11} />
                      {featured.category}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-emerald-400 transition-colors" style={{ fontFamily: 'Syne, sans-serif' }}>
                    {featured.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed line-clamp-3">{featured.excerpt}</p>
                  <div className="mt-6 flex items-center gap-2 text-emerald-400 text-sm font-medium">
                    Devamını Oku <ArrowRight size={14} />
                  </div>
                </div>
              </motion.article>
            )}

            {/* Sidebar posts */}
            <div className="flex flex-col gap-4">
              {rest.map((post, i) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, x: 30 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
                  className="glass gradient-border rounded-xl overflow-hidden card-hover group cursor-pointer flex gap-4 p-4"
                >
                  <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                    {post.image_url ? (
                      <img src={post.image_url} alt={post.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-indigo-500/20 to-pink-500/20 flex items-center justify-center">
                        <span className="text-lg font-bold gradient-text">{post.title?.charAt(0)}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-slate-500 mb-1.5">{formatDate(post.created_at)}</div>
                    <h4 className="text-sm font-semibold text-white group-hover:text-emerald-400 transition-colors line-clamp-2" style={{ fontFamily: 'Syne, sans-serif' }}>
                      {post.title}
                    </h4>
                    <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
                      <Tag size={9} />
                      {post.category}
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
