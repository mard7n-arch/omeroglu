import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const navItems = [
  { label: 'Ana Sayfa', href: '#hero' },
  { label: 'Hakkımda', href: '#about' },
  { label: 'Çalışmalar', href: '#projects' },
  { label: 'Uzmanlık', href: '#quality' },
  { label: 'Blog', href: '#blog' },
  { label: 'İletişim', href: '#contact' },
];

export default function Navbar({ settings }: { settings: Record<string, string> }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
  };

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'glass border-b border-white/5 py-3' : 'py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <motion.a
            href="#hero"
            onClick={e => { e.preventDefault(); scrollTo('#hero'); }}
            className="font-bold text-xl tracking-tight"
            style={{ fontFamily: 'Syne, sans-serif' }}
          >
            <span className="gradient-text">{settings.site_name || 'Z.Ö.'}</span>
          </motion.a>

          <div className="hidden md:flex items-center gap-8">
            {navItems.map(item => (
              <button
                key={item.href}
                onClick={() => scrollTo(item.href)}
                className="nav-link text-sm font-medium text-slate-400 hover:text-emerald-300 transition-colors"
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => scrollTo('#contact')}
              className="btn-primary text-sm py-2.5 px-6"
            >
              İletişime Geç
            </button>
          </div>

          <button
            className="md:hidden text-slate-400 hover:text-white transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-x-0 top-0 z-40 glass pt-20 pb-8 px-6 md:hidden"
            style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div className="flex flex-col gap-4">
              {navItems.map(item => (
                <button
                  key={item.href}
                  onClick={() => scrollTo(item.href)}
                  className="text-left text-base font-medium text-slate-300 hover:text-emerald-300 transition-colors py-2"
                >
                  {item.label}
                </button>
              ))}
              <button onClick={() => scrollTo('#contact')} className="btn-primary mt-2">
                İletişime Geç
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
